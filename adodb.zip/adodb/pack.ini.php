[adodb]
real_name = "AdoDB"
description = "Datenbank Abstraktionsschicht."
patchnotes[] = "5.0.7; Initial Release"
version = "5.0.7"
type = "run"
active = "true"
author = "John Lim"
mail = "jlim#natsoft.com "
license = "lgpl"
website = "http://adodb.sourceforge.net/"
[SETUP]