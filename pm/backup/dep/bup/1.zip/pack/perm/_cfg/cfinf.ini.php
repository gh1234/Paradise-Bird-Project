;<?php echo 'PDBP'; ?>
usual[dtype] = select
usual[extra][] = denie|DENIE
usual[extra][] = allow|ALLOW
maintenance[dtype] = bool
maintenance_message[dtype] = string
submit[dtype] = submit
submit[extra] = true