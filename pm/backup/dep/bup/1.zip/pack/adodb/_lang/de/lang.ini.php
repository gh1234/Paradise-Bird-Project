;<?php die('PDBP'); ?>
NO_CONFIG = "Die Konfiguration ist fehlerhaft."
CONNECTION_FAILED = "Es konnte keine Verbindung zur Datenbank hergestellt werden."
LAB_host = "Datenbankhost"
LAB_dbtype = "Datenbanktyp"
LAB_user = "Datenbankuser"
LAB_password = "Datenbankpasswort"
LAB_database = "Datenbankname"
LAB_submit = "Speichern"
