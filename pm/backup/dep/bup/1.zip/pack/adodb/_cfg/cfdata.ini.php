;<?php die('PDBP'); ?>
host = "localhost"
dbtype = "mysql"
user = "pdbp"
password = "KYPwpwbwhM48ZEJ7"
database = "pdbp"
submit = "1"
