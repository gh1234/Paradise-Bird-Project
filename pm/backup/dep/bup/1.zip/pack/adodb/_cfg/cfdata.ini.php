;<?php die('PDBP'); ?>
host = "localhost"
dbtype = "mysql"
user = "pdbp"
password = "pdbp"
database = "pdbp"
submit = "1"
