;<?php echo 'PDBP'; ?>
host[dtype] = string
host[extra] = 100
dbtype[dtype] = select
dbtype[extra][] = mysql|MySQL
dbtype[extra][] = mysqli|MySQLi
dbtype[extra][] = mssql|MsSQL
dbtype[extra][] = postgres|PostgresSQL
dbtype[extra][] = sqlite|SQLite
user[dtype] = string
password[dtype] = password
database[dtype] = string
submit[dtype] = submit
submit[extra] = true