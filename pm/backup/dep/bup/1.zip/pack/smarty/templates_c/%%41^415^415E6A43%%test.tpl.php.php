<?php /* Smarty version 2.6.26, created on 2009-08-24 21:23:49
         compiled from pack/index/test.tpl.php */ ?>
Hallo :D