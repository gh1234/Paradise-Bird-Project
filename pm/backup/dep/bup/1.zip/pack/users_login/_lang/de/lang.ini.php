;<?php echo 'PDBP'; ?>
login = "Administrationslogin"
username = "Username"
password = "Passwort"
login = "Login"
already_logged_in = "Sie sind bereits eingeloggt"