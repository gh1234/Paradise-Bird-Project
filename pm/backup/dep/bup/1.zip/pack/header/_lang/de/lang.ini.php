;<?php die('PDBP'); ?>
LAB_submit = "Speichern"
LAB_header = "Headerwerte"