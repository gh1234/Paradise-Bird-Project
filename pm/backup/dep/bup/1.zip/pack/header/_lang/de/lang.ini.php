;<?php die('PDBP'); ?>
LAB_submit = "Speichern"
LAB_header = "Headerwerte"
LAB_nocache = "Browsercache zulassen"
