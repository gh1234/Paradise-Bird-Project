;<?php echo 'PDBP'; ?>
LAB_index = "Startmodul"
LAB_param = "Startparameter, key=value"
LAB_submit = "Speichern"