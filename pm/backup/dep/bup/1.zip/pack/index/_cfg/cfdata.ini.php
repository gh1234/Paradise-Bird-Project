;<?php die('PDBP'); ?>
index = "hello_world"
param[] = "text=hello"
submit = "1"
