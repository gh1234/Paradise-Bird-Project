;<?php echo 'PDBP'; ?>
file[] = "pm"
file[] = "pack"
file[] = "index.php"
