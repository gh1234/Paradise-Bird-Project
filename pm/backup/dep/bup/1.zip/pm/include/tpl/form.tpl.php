<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $this->parse_lang_const('CFG_EDIT') . $packname; ?></title>
<style type="text/css">
<!--
table.cfgform{
 width: 100%;
}
p.tab{
 height: auto;
}
tr.c1{
 background-color: #CCCCCC;
}
tr.c2{
 background-color: #A0C0C0;
}
input{
 background: transparent;
}
select{
 background: transparent;
}
-->
</style>
<?php 
echo $js;
?>
</head>

<body>
<?php echo $form; ?>
</body>
</html>