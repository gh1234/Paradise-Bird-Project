[hello_world]
real_name = "Hallo Welt!"
description = "Dieses Paket gibt Hallo Welt aus."
patchnotes[] = "0.1.0; Release Alpha"
patchnotes[] = "0.1.1; Bug gefixt"
version = "0.1.1"
type = "run"
active = "true"
author = "GH1234"
mail = "jonas.schwabe@gmail.com"
license = "gpl"
website = "http://www.cascaded-web.com"
[SETUP]
md5[] = "0.1.1;_init.php;d41d8cd98f00b204e9800998ecf8427e"